<p class="copyright pull-right">
    &copy;
    <script>
        document.write(new Date().getFullYear())
    </script>
    <a href="#"> DexTeam </a>, made with <i class="fa fa-heart" aria-hidden="true"></i>
</p>
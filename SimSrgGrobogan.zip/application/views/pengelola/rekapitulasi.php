<div class="row">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="blue">
                    <i class="material-icons">timeline</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Rekap Pengujian Diterima (Kecamatan)</h4>
                </div>
                <div id="chartKecamatan" class="ct-chart"></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="blue">
                    <i class="material-icons">timeline</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Rekap Pengujian</h4>
                </div>
                <div id="chartPengujian" class="ct-chart"></div>
            </div>
        </div>
    </div>
</div>
